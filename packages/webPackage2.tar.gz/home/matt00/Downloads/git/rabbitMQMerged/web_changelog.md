commit a5959c18fac39b1343a3ef3617f6b51af23868ca
Merge: 2b978db 7795afd
Author: mattgclaudio <mattgclaudio@gmail.com>
Date:   Mon Nov 2 00:40:36 2020 +0000

    Merge branch 'webVM' of https://github.com/smalishuk/rabbitMQMerged into webVM

commit 2b978db423b006792a4ad30fc072faba1219a757
Author: mattgclaudio <mattgclaudio@gmail.com>
Date:   Mon Nov 2 00:40:16 2020 +0000

    cleaning up action page

commit 7795afd214c1c5ae2b12704e1a27c7173fbb10c4
Author: mattgclaudio <mc824@njit.edu>
Date:   Sun Nov 1 19:10:45 2020 -0500

    Update README.md

commit 841ca08b9ca28444dd4d17d38b01c2bee7ab15ad
Author: mattgclaudio <mattgclaudio@gmail.com>
Date:   Mon Nov 2 00:06:19 2020 +0000

    updated action.php to reflect dmz changes

commit 5ece7e67e34d6b8a26b7be80788bc43a65a4d138
Author: mattgclaudio <mc824@njit.edu>
Date:   Tue Oct 27 19:32:53 2020 -0400

    Update action.php

commit 7cede1696180b00046f1949f63a31a2eca249d85
Author: mattgclaudio <mattgclaudio@gmail.com>
Date:   Tue Oct 27 07:45:34 2020 +0000

    Bootstrap4

commit 40d1d80285da7d7bca960d5a9c58518363aaa43c
Author: mattgclaudio <mattgclaudio@gmail.com>
Date:   Mon Oct 26 14:44:00 2020 +0000

    web server updates

commit 7c3ec8bce2a90420cb2001296a81c10e4ed2536a
Author: mattgclaudio <mc824@njit.edu>
Date:   Mon Oct 26 02:53:51 2020 -0400

    Create testFileForDMZAdditions

commit fd68981113d639eef704ac2cacd735c6f90b6168
Author: mattgclaudio <mc824@njit.edu>
Date:   Tue Oct 20 15:10:08 2020 -0400

    Add files via upload

commit 798f298ee05d51909bc5f69abbaefaf2066d6716
Author: mattgclaudio <mc824@njit.edu>
Date:   Tue Oct 20 15:05:33 2020 -0400

    Update README.md

commit 39f41e9c2b1774396d64be3fd051f955dfc0e1c3
Author: smalishuk <smalishuk@gmail.com>
Date:   Mon Oct 19 20:55:21 2020 -0400

    deleted swap file

commit 097ed8dc8efd2222d99a93cf047cb90eb8f1201a
Author: smalishuk <smalishuk@gmail.com>
Date:   Mon Oct 19 20:53:38 2020 -0400

    Additional front end files, still working on these

commit 5052e56a3735c3af577f798c1a4fb6648cecd225
Author: smalishuk <smalishuk@gmail.com>
Date:   Mon Oct 19 20:52:45 2020 -0400

    Deleted old css

commit aa1dd32ce03d0ae18f91cd53475357c19287c0ec
Author: smalishuk <smalishuk@gmail.com>
Date:   Mon Oct 19 20:31:50 2020 -0400

    This a folder imported from my previous repo containing all my necessarry files - Sam

commit f9e737e980255378615526bb911acfa7ff51eeb5
Author: smalishuk <55061544+smalishuk@users.noreply.github.com>
Date:   Mon Oct 19 19:50:05 2020 -0400

    Update README.md

commit 6c8f78fee0c5ee6d0b22a300c3bb95b947c043ef
Author: smalishuk <55061544+smalishuk@users.noreply.github.com>
Date:   Mon Oct 19 19:46:44 2020 -0400

    Initial commit
