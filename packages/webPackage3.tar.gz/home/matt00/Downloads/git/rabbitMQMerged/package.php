<?php
 
function createPackage($versionNum) {
	
	# we could pass a time or version number as a parameter and update the 	       # package name that way, or differentiate them some other way,
	# but we should probably not just have them all named the same.
	# either way here we compress the contents of the webfacing 
	# directory and the rabbit directory that holds the client
	# functions and such.

	# here
	$fullname = 'webPackage'.$versionNum.'.tar.gz';
	
	$compress = 'tar -czf '.$fullname.' /var/www/html/stockTracker/ /home/matt00/Downloads/git/rabbitMQMerged/';
	
	shell_exec(escapeshellcmd($compress));

	$deliver = 'scp '.$fullname.' matt@192.168.1.182:/home/matt/git/rabbitMQMerged/packages';

	shell_exec(escapeshellcmd($deliver));

}

createPackage('3');


