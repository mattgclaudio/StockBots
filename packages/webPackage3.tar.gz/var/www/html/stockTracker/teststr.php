<?php

$tax = "ABCD";
$str = "rolling";

echo($tax.$str);
