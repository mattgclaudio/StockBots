# webVM

so the user is presented first with login.html, credentials are shot over and returned to login.php, if it was successful they can move to action.php and perform tasks as needed. ServerClient.php sits in a folder with all the neccessary RabbitMQ files for reaching out to the rabbitVM for message transfer.Keeps the rabbit.ini file for that. All the current webpages are in the webpages directory!!
